package com.example.seminar2HW;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Seminar2HwApplication {

	public static void main(String[] args) {
		SpringApplication.run(Seminar2HwApplication.class, args);
	}

}
