package com.example.seminar3HW;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Seminar3HwApplicationTests {

	@Test
	void contextLoads() {
	}

}
