package com.example.seminar3HW;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Seminar3HwApplication {

	public static void main(String[] args) {
		SpringApplication.run(Seminar3HwApplication.class, args);
	}

}
